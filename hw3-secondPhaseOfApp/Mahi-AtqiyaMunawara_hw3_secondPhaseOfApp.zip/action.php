<!-- Code Source: Atqiya Munawara Mahi, unless otherwise specified -->
<!-- Helping Reference (Modified) : https://www.w3schools.com/tags/ -->
<?php
 $path = 'info.txt';
 if (isset($_POST['loc']) && isset($_POST['addr'])) {
    $fh = fopen($path,"a+");
    $string = $_POST['loc'].' - '.$_POST['addr'].' - '.$_POST['like'].' - '.$_POST['famfrom'].' - '.$_POST['age'].' - '.$_POST['pob'].' - '.$_POST['praddr'].' - '.$_POST['likeaddr'].' - '.$_POST['sigaddr'].' - '.$_POST['anyelse'].' - '.$_POST['mine'].' - '.$_POST['family'].' - '.$_POST['friend'].' - '.$_POST['f1'].' - '.$_POST['f2']."\n";
    fwrite($fh,$string); 
    fclose($fh); 
    echo 'Submission Successful';
 }
?>