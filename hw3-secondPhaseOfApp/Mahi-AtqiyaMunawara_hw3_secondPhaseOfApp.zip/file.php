<!-- Code Source: Atqiya Munawara Mahi, unless otherwise specified -->
<!-- Helping Reference (Modified) : https://www.w3schools.com/tags/ -->
<?php
$target_dir = "file/";
$target_file = $target_dir . basename($_FILES["myfile"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image


  // Check file size
if ($_FILES["myfile"]["size"] > 500000) {
    echo "File too large.";
    $uploadOk = 0;
}


// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "File not uploaded.";
  // if everything is ok, try to upload file
  } else {
    if (move_uploaded_file($_FILES["myfile"]["tmp_name"], $target_file)) {
      echo "The file ". htmlspecialchars( basename( $_FILES["myfile"]["name"])). " has been uploaded.";
    } else {
      echo "Error in uploading file.";
    }
  }

?>